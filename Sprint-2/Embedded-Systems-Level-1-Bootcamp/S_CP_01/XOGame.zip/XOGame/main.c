#include <stdio.h>
#include <stdlib.h>
#include "App.h"


int main()
{
    unsigned int GameIndex;
    unsigned int Winner = 0;

    for(GameIndex = 0; ((GameIndex < 9) && (Winner == 0)); GameIndex++)
    {
        GridControl();
        PlayerTurn();
        Winner = CheckScore();
    }
    DisplayScore(Winner);
    return 0;
}
