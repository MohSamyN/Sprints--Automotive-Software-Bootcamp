#include "App.h"


static uint8_t GridValues[9] = {'1', '2', '3', '4', '5', '6', '7' , '8', '9'};


/* A Function to update the grid after each player's turn */
void GridControl(void)
{
    system("cls");
    printf("\n\t\t\t   Welcome to X-O Game\n");
    printf("\t\t     [Player 1 -> X, Player 2 -> Y]");
    printf("\n\t\t\t-------------------------");
    printf("\n\t\t\t|   %c   |   %c   |   %c   |", GridValues[0], GridValues[1], GridValues[2]);
    printf("\n\t\t\t-------------------------");
    printf("\n\t\t\t|   %c   |   %c   |   %c   |", GridValues[3], GridValues[4], GridValues[5]);
    printf("\n\t\t\t-------------------------");
    printf("\n\t\t\t|   %c   |   %c   |   %c   |", GridValues[6], GridValues[7], GridValues[8]);
    printf("\n\t\t\t-------------------------");
}

/* A Function to manage selection of each player turn */
void PlayerTurn(void)
{
    int PlayerChoice;
    static uint8_t PlayerTurn = 1;
    uint8_t WrongEntryFlag = 1;

    /* A loop to make sure that it takes from the user the right input */
    while(WrongEntryFlag != 0)
    {
        /* Asking the user to enter the place he/she wanted to play (1-9) */
        printf("\nPlayer %d's turn: ", PlayerTurn);
        scanf("%d", &PlayerChoice);
        /* Decrementing the value of the player choice to match the indices of the array */
        PlayerChoice--;
        /* Checking if the player's choice is not between 0 and 8 */
        if((PlayerChoice < 0) || (PlayerChoice > 8))
        {
            printf("\nWrong entry, please enter a number between 1 and 9");
        }
        /* Checking if the player's choice is already taken */
        else if((GridValues[PlayerChoice] == 'X') || (GridValues[PlayerChoice] == 'O'))
        {
            printf("\nWrong entry, number is already taken, please enter another number");
        }
        else
        {
            WrongEntryFlag = 0;
        }
    }
    /* Checking whether it is the turn of player 1 or player 2 */
    if(PlayerTurn == 1)
    {
        /* Updating the selected cell with X */
        GridValues[PlayerChoice] = 'X';
        /* Incrementing player 1 turn to switch to player 2 on next turn */
        PlayerTurn++;
    }
    else
    {
        /* Updating the selected cell with O */
        GridValues[PlayerChoice] = 'O';
        /* Decrementing player 2 turn to switch to player 1 on next turn */
        PlayerTurn--;
    }
}

/* A Function to check the winning scenarios and determine the winner */
uint8_t CheckScore(void)
{
    static uint8_t Winner = 0;

    /* Checking both first row and column */
    /* -------------
       | * | * | * |
       -------------
       | * |   |   |
       -------------
       | * |   |   |
       ------------- */
    if(((GridValues[0] == GridValues[1]) && (GridValues[1] == GridValues[2])) ||
       ((GridValues[0] == GridValues[3]) && (GridValues[3] == GridValues[6])))
    {
        /* Checking if the values are X, then player 1 is the winner */
        if(GridValues[0] == 'X')
        {
            Winner = 1;
        }
        /* Checking if the values are O, then player 2 is the winner */
        else
        {
            Winner = 2;
        }
    }
    /* Checking both second row and column, as well as both diagonals */
    /* -------------
       | * | . | * |
       -------------
       | . | * | . |
       -------------
       | * | . | * |
       ------------- */
    else if(((GridValues[3] == GridValues[4]) && (GridValues[4] == GridValues[5])) ||
            ((GridValues[1] == GridValues[4]) && (GridValues[4] == GridValues[7])) ||
            ((GridValues[0] == GridValues[4]) && (GridValues[4] == GridValues[8])) ||
            ((GridValues[2] == GridValues[4]) && (GridValues[4] == GridValues[6])))
    {
        /* Checking if the values are X, then player 1 is the winner */
        if(GridValues[4] == 'X')
        {
            Winner = 1;
        }
        /* Checking if the values are O, then player 2 is the winner */
        else
        {
            Winner = 2;
        }
    }
    /* Checking both last row and column */
    /* -------------
       |   |   | * |
       -------------
       |   |   | * |
       -------------
       | * | * | * |
       ------------- */
    else if(((GridValues[6] == GridValues[7]) && (GridValues[7] == GridValues[8])) ||
            ((GridValues[2] == GridValues[5]) && (GridValues[5] == GridValues[8])))
    {
        /* Checking if the values are X, then player 1 is the winner */
        if(GridValues[8] == 'X')
        {
            Winner = 1;
        }
        /* Checking if the values are O, then player 2 is the winner */
        else
        {
            Winner = 2;
        }
    }
    else
    {
    }
    return Winner;
}

/* A Function to display the winner of the game */
void DisplayScore(uint8_t Winner)
{
    /* Displaying the final grid after last update at the end of the game */
    GridControl();
    /* Checking whether player 1, player 2 wins, or it is a draw */
    if((Winner == 1) || (Winner == 2))
    {
        printf("\n\nPlayer %d won", Winner);
    }
    else
    {
        printf("\n\nDraw");
    }
}
