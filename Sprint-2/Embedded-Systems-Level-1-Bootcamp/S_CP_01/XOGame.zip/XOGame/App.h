#ifndef APP_H_
#define APP_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* A Function to update the grid after each player's turn */
void GridControl(void);
/* A Function to manage selection of each player turn */
void PlayerTurn(void);
/* A Function to check the winning scenarios and determine the winner */
uint8_t CheckScore(void);
/* A Function to display the winner of the game */
void DisplayScore(uint8_t Winner);

#endif // APP_H_
