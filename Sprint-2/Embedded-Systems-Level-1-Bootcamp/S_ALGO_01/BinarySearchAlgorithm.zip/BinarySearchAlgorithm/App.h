#ifndef APP_H_
#define APP_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* A Function to do binary search to find whether a specific number is found in an array or not */
int8_t BinarySearch(uint32_t* Arr, uint8_t Size, uint32_t Number);

#endif // APP_H_
