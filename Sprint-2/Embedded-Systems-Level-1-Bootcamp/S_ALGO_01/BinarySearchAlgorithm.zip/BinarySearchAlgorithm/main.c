#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "App.h"


int main()
{
    uint32_t Arr[10] = {0, 1, 2, 3, 8, 5, 6, 7, 4, 9};
    int8_t Index;
    Index = BinarySearch(Arr, 10, 8);
    if(Index == -1)
    {
        printf("Number is not found in the array");
    }
    else
    {
        printf("Number is found in the array at Index: %d", Index);
    }
    return 0;
}
