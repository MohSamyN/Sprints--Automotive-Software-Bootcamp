#include "App.h"


/* A private Function to check if the array is sorted or not */
static uint8_t ArrayIsSortedCheck(uint32_t* Arr, uint8_t Size);
/* A private Function to sort the array using Selection Sort */
static void SelectionSort(uint32_t* Arr, uint8_t Size);


/* A Function to do binary search to find whether a specific number is found in an array or not */
int8_t BinarySearch(uint32_t* Arr, uint8_t Size, uint32_t Number)
{
    int8_t ArrIndex = -1;
    uint8_t ArrSortCheckFlag;
    uint8_t StartPosition = 0;
    uint8_t EndPosition = Size - 1;
    uint8_t MidPosition = (StartPosition + EndPosition) / 2;
    uint8_t BinarySearchFlag = 0;

    /* Checking if the array is sorted or not */
    ArrSortCheckFlag = ArrayIsSortedCheck(Arr, Size);
    /* Checking the flag returning from the previous function, stating whether the array is sorted or not */
    if(ArrSortCheckFlag == 0)
    {
        /* Running the Selection Sort function to sort the array */
        SelectionSort(Arr, Size);
    }
    else
    {
    }
    do
    {
        /* Checking if the Start, Mid and End position are having the same value */
        if((StartPosition == MidPosition) && (MidPosition == EndPosition))
        {
            /* Checking if the value of number in the array at the Start position is the same as the input number */
            if(*(Arr + StartPosition) == Number)
            {
                /* Assigning the value of Start position index into the returning index variable */
                ArrIndex = StartPosition;
            }
            else
            {
            }
            /* Raising the flag of binary search status to break the loop and return the index */
            BinarySearchFlag = 1;
        }
        else
        {
            /* Checking if the value of number in the array at the Mid position is less than the input number */
            if(*(Arr + MidPosition) < Number)
            {
                /* Updating the Start position by one after the Mid position */
                StartPosition = MidPosition + 1;
                /* Recalculating the new value of the Mid position */
                MidPosition = (StartPosition + EndPosition) / 2;
            }
            /* Checking if the value of number in the array at the Mid position is greater than the input number */
            else if(*(Arr + MidPosition) > Number)
            {
                /* Updating the End position by one before the Mid position */
                EndPosition = MidPosition - 1;
                /* Recalculating the new value of the Mid position */
                MidPosition = (StartPosition + EndPosition) / 2;
            }
            else
            {
                /* Assigning the value of Mid position index into the returning index variable */
                ArrIndex = MidPosition;
                /* Raising the flag of binary search status to break the loop and return the index */
                BinarySearchFlag = 1;
            }
        }
    } while(BinarySearchFlag == 0);
    return ArrIndex;
}


/* A private Function to check if the array is sorted or not */
static uint8_t ArrayIsSortedCheck(uint32_t* Arr, uint8_t Size)
{
    uint8_t ArrSortCheckFlag = 1;
    uint8_t ArrIndex;

    /* A loop to pass on every single element in the array and state whether the array is sorted or not */
    for(ArrIndex = 0; (ArrIndex < (Size - 1)); ArrIndex++)
    {
        /* Checking if the value of the current position is greater than that it the next position */
        if(*(Arr + ArrIndex) > *(Arr + ArrIndex + 1))
        {
            /* Lowering the flag of the array stating that the array is not sorted */
            ArrSortCheckFlag = 0;
            /* Updating the value of the loop to break it */
            ArrIndex = Size - 1;
        }
        else
        {
        }
    }
    return ArrSortCheckFlag;
}

/* A private Function to sort the array using Selection Sort */
static void SelectionSort(uint32_t* Arr, uint8_t Size)
{
    uint32_t TempNumber;
    uint8_t ArrIndex1;
    uint8_t ArrIndex2;

    /* Two loops to pass on every single element in the array and swapping elements to sort the array in an ascending order  */
    for(ArrIndex1 = 0; (ArrIndex1 < (Size - 1)); ArrIndex1++)
    {
        for((ArrIndex2 = (ArrIndex1 + 1)); (ArrIndex2 < (Size - 1)); ArrIndex2++)
        {
            if(*(Arr + ArrIndex1) > *(Arr + ArrIndex2))
            {
                TempNumber = *(Arr + ArrIndex1);
                *(Arr + ArrIndex1) = *(Arr + ArrIndex2);
                *(Arr + ArrIndex2) = TempNumber;
            }
            else
            {
            }
        }
    }
}
