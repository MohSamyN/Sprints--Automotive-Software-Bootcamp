#ifndef STACK_H_
#define STACK_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define STACK_SIZE          10

/* A Function to push data to the stack */
void Push(uint8_t u8_Data);
/* A Function to pull data from the stack */
uint8_t Pull(void);
/* A Function to print all data found inside the stack */
void PrintStack(void);

#endif // STACK_H_
