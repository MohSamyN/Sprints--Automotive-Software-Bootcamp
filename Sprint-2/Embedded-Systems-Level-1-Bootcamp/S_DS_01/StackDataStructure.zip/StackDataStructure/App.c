#include "App.h"


/* A Function to check whether the expression has a balanced parentheses or not */
uint8_t* BalancedParentheses(uint8_t* Expression)
{
    uint8_t Status[12];
    uint8_t* StatusPtr = Status;
    uint8_t Index = 0;
    uint8_t Data;
    uint8_t BalanceFlag = 0;

    /* A loop to fetch every single character from the expression till the null character */
    while((*(Expression + Index) != '\n') && (BalanceFlag == 0))
    {
        /* Checking if the current expression character is (, { or [ */
        if((*(Expression + Index) == '(') || (*(Expression + Index) == '{') || (*(Expression + Index) == '['))
        {
            /* Pushing the current expression character to the stack */
            Push(*(Expression + Index));
        }
        /* Checking if the current expression character is ), } or ] */
        else if((*(Expression + Index) == ')') || (*(Expression + Index) == '}') || (*(Expression + Index) == ']'))
        {
            /* Pulling the stored data from the stack */
            Data = Pull();
            /* Checking if the stored data from the stack is: (, { or [ and the current expression character is: ), } or ] respectively */
            if(((Data == '(') && (*(Expression + Index) == ')')) || ((Data == '{') && (*(Expression + Index) == '}')) || ((Data == '[') && (*(Expression + Index) == ']')))
            {
            }
            else
            {
                /* Raising the flag of not balanced flag to break the loop and state that the expression is not balanced */
                BalanceFlag = 1;
            }
        }
        /* Incrementing the index to move to the next character in the expression */
        Index++;
    }
    /* Pulling a data from the stack to check whether it's empty or not */
    Data = Pull();
    system("cls");
    /* Checking if the not balanced flag is not raised and there is no data left in the stack */
    if((BalanceFlag == 0) && (Data == 0))
    {
        /* Updating the returning array as Balanced */
        StatusPtr = (uint8_t*)"Balanced";
    }
    else
    {
        /* Updating the returning array as Not Balanced */
        StatusPtr = (uint8_t*)"Not Balanced";
    }
    return StatusPtr;
}
