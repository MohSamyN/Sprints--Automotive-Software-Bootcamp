#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "App.h"

int main()
{
    uint8_t Array[20];
    uint8_t* ArrayPtr = Array;
    uint8_t Expression[50] = "{ 2 + (5 * 4) - 3}\n";

    ArrayPtr = BalancedParentheses(Expression);
    printf("%s", ArrayPtr);
    return 0;
}
