#include "Stack.h"


static uint8_t Stack[STACK_SIZE] = {0};
static int8_t Top = -1;


/* A Function to push data to the stack */
void Push(uint8_t u8_Data)
{
    /* Checking if the top stack pointer equals the stack size - 1 (Stack is full) */
    if(Top == (STACK_SIZE - 1))
    {
        /* Printing that stack overflow occurs */
        printf("Error! ... Stack Overflow\n");
    }
    else
    {
        /* Incrementing the top stack pointer by one */
        Top++;
        /* Pushing the value of the input data into the stack */
        Stack[Top] = u8_Data;
    }
}

/* A Function to pull data from the stack */
uint8_t Pull(void)
{
    uint8_t u8_Data;

    /* Checking if the top stack pointer equals the -1 (Stack is empty) */
    if(Top == -1)
    {
        /* Printing that stack is empty */
        printf("Error! ... Stack is Empty\n");
        /* Setting the returning data as zero */
        u8_Data = 0;
    }
    else
    {
        /* Poping the value of the input data from the stack */
        u8_Data = Stack[Top];
        /* Clearing the value of the data inside the stack */
        Stack[Top] = 0;
        /* Decrementing the top stack pointer by one */
        Top--;
    }
    return u8_Data;
}

/* A Function to print all data found inside the stack */
void PrintStack(void)
{
    uint8_t StackIndex;

    printf("{");
    /* A loop to print every single data inside the stack */
    for(StackIndex = 0; StackIndex < STACK_SIZE; StackIndex++)
    {
        if(StackIndex == (STACK_SIZE - 1))
        {
            printf("%d}\n", Stack[StackIndex]);
        }
        else
        {
            printf("%d, ", Stack[StackIndex]);
        }
    }
}
