#ifndef APP_H_
#define APP_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "Stack.h"

/* A Function to check whether the expression has a balanced parentheses or not */
uint8_t* BalancedParentheses(uint8_t* Expression);

#endif // APP_H_
