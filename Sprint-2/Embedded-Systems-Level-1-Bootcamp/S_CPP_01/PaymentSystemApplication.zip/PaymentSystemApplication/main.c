#include <stdio.h>
#include <stdlib.h>
#include "App.h"


int main()
{
    uint8_t AnotherOperationFlag = 'y';
    uint8_t MaxAmountFlag;

    while(AnotherOperationFlag == 'y')
    {
        printf("Please Enter Card Data:\n");
        printf("----------------------\n");
        GetCardData();
        printf("Please Enter Terminal Data:\n");
        printf("--------------------------\n");
        MaxAmountFlag = GetTerminalData();
        CheckTransactionValidty(MaxAmountFlag);
        printf("Do you want to continue (y/n)?\n");
        scanf("%s", &AnotherOperationFlag);
        int c = getchar();
    }
    return 0;
}
