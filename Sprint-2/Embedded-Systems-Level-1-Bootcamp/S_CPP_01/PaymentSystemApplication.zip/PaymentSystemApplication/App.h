#ifndef APP_H_
#define APP_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* An Enum for declining/approving the transaction */
typedef enum EN_TransStat_t
{
    DECLINED,
    APPROVED
} EN_TransStat_t;

/* A Struct for saving the information of a card data */
typedef struct ST_CardData_t
{
    uint8_t CardHolderName[25];
    uint8_t PrimaryAccountNumber[20];
    uint8_t CardExpirationDate[6];
} ST_CardData_t;

/* A Struct for saving the information on a transaction */
typedef struct ST_TerminalData_t
{
    float TransAmount;
    float MaxTransAmount;
    uint8_t TransactionDate[11];
} ST_TerminalData_t;

/* A Struct for saving both card data and transaction information, as well as the state of the transaction */
typedef struct ST_Transaction_t
{
    ST_CardData_t CardHolderData;
    ST_TerminalData_t TransData;
    EN_TransStat_t TransStat;
} ST_Transaction_t;

/* A Struct which acts as a server data, holding both the primary account numbers and their balances */
typedef struct ST_AccountBalance_t
{
    float Balance;
    uint8_t PrimaryAccountNumber[20];
} ST_AccountBalance_t;


/* A Function to get the information of card data and save it in its Struct */
void GetCardData(void);

/* A Function to get the information of terminal data and save it in its Struct */
uint8_t GetTerminalData(void);

/* A Function to check for the validty of the transaction, whether it's approved or declined */
void CheckTransactionValidty(uint8_t MaxAmountFlag);

#endif // APP_H_
