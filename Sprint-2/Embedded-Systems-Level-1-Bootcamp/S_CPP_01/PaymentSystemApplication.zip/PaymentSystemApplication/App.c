#include "App.h"

static ST_Transaction_t Transaction;

static ST_AccountBalance_t ServerData[100] =
{
    {100,       "123456789"},
    {6000,      "234567891"},
    {3250.25,   "567891234"},
    {1500.12,   "456789123"},
    {500,       "258649173"},
    {2100,      "654823719"},
    {0,         "971362485"},
    {1,         "793148625"},
    {10.12,     "123123456"},
    {0.55,      "456789321"}
};


/* A private Function to convert each number from string to a decimal number */
static uint8_t ConvertToInteger(uint8_t* String, uint8_t StartIndex);


/* A Function to get the information of card data and save it in its Struct */
void GetCardData(void)
{
    ST_CardData_t CardData;

    /* Asking the user to enter the full name of the card holder */
    printf("Please Enter the Card Holder Name:\n");
    fgets((char*)CardData.CardHolderName, 25, stdin);
    /* Asking the user to enter the primary account number */
    printf("Please Enter the Primary Account Number:\n");
    scanf("%s", CardData.PrimaryAccountNumber);
    /* Asking the user to enter the card expiry date */
    printf("Please Enter the Card Expiry Date:\n");
    scanf("%s", CardData.CardExpirationDate);
    /* Adding all card data information into Transaction Struct */
    Transaction.CardHolderData = CardData;
}

/* A Function to get the information of terminal data and save it in its Struct */
uint8_t GetTerminalData(void)
{
    ST_TerminalData_t TerminalData;
    uint8_t MaxAmountFlag = 0;

    /* Setting the maximum transaction amount to 5000 */
    TerminalData.MaxTransAmount = 5000.0;
    /* Asking the user to enter the transaction amount */
    printf("Please Enter the Transaction Amount:\n");
    scanf("%f", &TerminalData.TransAmount);
    /* Checking if the transaction amount is less than or equal the maximum transaction amount */
    if(TerminalData.TransAmount <= TerminalData.MaxTransAmount)
    {
        /* Asking the user to enter the transaction date */
        printf("Please Enter Transaction Date:\n");
        scanf("%s", TerminalData.TransactionDate);
        /* Adding all terminal data information into Transaction Struct */
        Transaction.TransData = TerminalData;
    }
    else
    {
        /* Raising the maximum amount flag, as the current transaction amount exceeds the maximum amount */
        MaxAmountFlag = 1;
    }
    return MaxAmountFlag;
}

/* A Function to check for the validty of the transaction, whether it's approved or declined */
void CheckTransactionValidty(uint8_t MaxAmountFlag)
{
    uint8_t CardExpiryYear;
    uint8_t TransactionYear;
    uint8_t CardExpiryMonth;
    uint8_t TransactionMonth;
    uint8_t i;
    uint8_t j;

    /* Checking if the maximum amount flag is raised or not */
    if(MaxAmountFlag == 0)
    {
        printf("Verifying Data from the server...\n");
        /* Converting the card expiry year from string into decimal number */
        CardExpiryYear = ConvertToInteger(Transaction.CardHolderData.CardExpirationDate, 3);
        /* Converting the transaction year from string into decimal number */
        TransactionYear = ConvertToInteger(Transaction.TransData.TransactionDate, 8);
        /* Converting the card expiry month from string into decimal number */
        CardExpiryMonth = ConvertToInteger(Transaction.CardHolderData.CardExpirationDate, 0);
        /* Converting the transaction month from string into decimal number */
        TransactionMonth = ConvertToInteger(Transaction.TransData.TransactionDate, 3);
        /* Checking if the card expiry year is greater than the transaction year
           OR the card expiry year is equal to the transaction year but the card expiry month is greater than the transaction month*/
        if((CardExpiryYear > TransactionYear) || ((CardExpiryYear == TransactionYear) && (CardExpiryMonth > TransactionMonth)))
        {
            /* A loop to pass over every single server data object in the Server Data array of structs */
            for(i = 0; i < 10; i++)
            {
                /* A loop to pass over every single character on each primary account number */
                for(j = 0; j < 10; j++)
                {
                    /* Checking if the primary account number of the account holder is found in the Server Data array of structs */
                    if(Transaction.CardHolderData.PrimaryAccountNumber[j] != ServerData[i].PrimaryAccountNumber[j])
                    {
                        break;
                    }
                    else
                    {
                    }
                }
                /* Checking if j reaches 10, that means that the current primary account number is found in Server Data */
                if(j == 10)
                {
                    break;
                }
                else
                {
                }
            }
            /* Checking if i is less than 10, that means that the primary account number is found in Server Data array of structs */
            if(i < 10)
            {
                /* Checking if there is an enough balance to complete the transaction process */
                if(Transaction.TransData.TransAmount <= ServerData[i].Balance)
                {
                    /* Assigning the state of the transaction as approved */
                    Transaction.TransStat = APPROVED;
                }
                else
                {
                    /* Assigning the state of the transaction as declined */
                    Transaction.TransStat = DECLINED;
                }
            }
            else
            {
                /* Assigning the state of the transaction as declined */
                Transaction.TransStat = DECLINED;
            }
        }
        else
        {
            /* Assigning the state of the transaction as declined */
            Transaction.TransStat = DECLINED;
        }
    }
    else
    {
        /* Assigning the state of the transaction as declined */
        Transaction.TransStat = DECLINED;
    }
    /* Checking if the state of the transaction is approved or declined */
    if(Transaction.TransStat == APPROVED)
    {
        /* Printing out that the transaction is approved */
        printf("The Transaction is APPROVED\n");
    }
    else
    {
        /* Printing out that the transaction is declined */
        printf("The Transaction is DECLINED\n");
    }
}


/* A private Function to convert each number from string to a decimal number */
static uint8_t ConvertToInteger(uint8_t* String, uint8_t StartIndex)
{
    uint8_t TempArray[2];
    uint8_t TempIndex;
    uint8_t DecimalNumber;

    /* A loop to take every character from the input string into a temporary array */
    for(TempIndex = 0; TempIndex < 2; TempIndex++)
    {
        TempArray[TempIndex] = *(String + StartIndex + TempIndex);
    }
    /* Converting the value of temporary array from string into a decimal number */
    DecimalNumber = (uint8_t)atoi((char*)TempArray);
    return DecimalNumber;
}
